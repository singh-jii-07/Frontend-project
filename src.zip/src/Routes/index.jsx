import AdminLayout from "./admin";
import MemberLayout  from "./member";
import { createBrowserRouter } from "react-router-dom";
const route= createBrowserRouter([
    <AdminLayout/>,
    <MemberLayout/>
])
export default route;