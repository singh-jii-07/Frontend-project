import React from 'react'

const index = () => {
  return (
    <div>
      admin index
    </div>
  )
}

export default index
