import React from 'react'

const index = () => {
  return (
    <div>
      member index
    </div>
  )
}

export default index
