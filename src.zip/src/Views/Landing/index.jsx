import React from 'react'

const index = () => {
  return (
    <div>
      landing index
    </div>
  )
}

export default index
